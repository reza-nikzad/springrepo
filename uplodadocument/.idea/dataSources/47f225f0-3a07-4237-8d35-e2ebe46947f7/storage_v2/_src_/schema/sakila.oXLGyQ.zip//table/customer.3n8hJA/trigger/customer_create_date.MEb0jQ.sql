create definer = root@localhost trigger customer_create_date
    before insert
    on customer
    for each row
    SET NEW.create_date = NOW();

